<?php
// MySQL database credentials
$servername = "localhost";
$username = "root";
$password = "Mudit@2002";
$dbname = "Fetch";

// Connect to MySQL server
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_GET['email'];

// Fetch the health report path from the database based on the email ID
$sql = "SELECT health_report FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $healthReportPath = $row['health_report'];

    // Provide the health report as a downloadable file
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . basename($healthReportPath) . '"');
    readfile($healthReportPath);
} else {
    echo "No health report found for the specified email ID.";
}

// Close the database connection
$conn->close();
?>
