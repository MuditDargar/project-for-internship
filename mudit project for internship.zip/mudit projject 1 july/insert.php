<?php
// MySQL database credentials
$servername = "localhost";
$username = "root";
$password = "Mudit@2002";
$dbname = "Insert";

// Connect to MySQL server
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$email = $_POST['email'];

// Upload health report
$targetDirectory = "uploads/";
$targetFile = $targetDirectory . basename($_FILES["healthReport"]["name"]);
$uploadOk = 1;
$fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Check if the uploaded file is a PDF
if ($fileType != "pdf") {
    echo "Only PDF files are allowed.";
    $uploadOk = 0;
}

// Check if file already exists
if (file_exists($targetFile)) {
    echo "File already exists.";
    $uploadOk = 0;
}

// Check file size (limit to 5MB)
if ($_FILES["healthReport"]["size"] > 5 * 1024 * 1024) {
    echo "File size exceeds the limit (5MB).";
    $uploadOk = 0;
}

// Upload the file if all checks pass
if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES["healthReport"]["tmp_name"], $targetFile)) {
        // File uploaded successfully, insert data into the database
        $sql = "INSERT INTO users (name, age, weight, email, health_report) VALUES ('$name', '$age', '$weight', '$email', '$targetFile')";

        if ($conn->query($sql) === TRUE) {
            echo "User details and health report inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error uploading the file.";
    }
}

// Close the database connection
$conn->close();
?>
